# app/routers/checklists.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from datetime import datetime

from app.database import get_db
from app import models
from app.routers.auth import get_current_user

router = APIRouter(prefix="/checklists", tags=["Checklists"])


# ----------- ADMIN ENDPOINTS -----------

@router.post("/")
def create_checklist(
    movie_id: int,
    items: List[str],
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    """Admin creates a checklist for a specific movie"""
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Only admin can create checklists")

    checklist = models.Checklist(movie_id=movie_id, created_at=datetime.utcnow())
    db.add(checklist)
    db.commit()
    db.refresh(checklist)

    for item in items:
        ci = models.ChecklistItem(
            checklist_id=checklist.id,
            description=item,
            status="pending"
        )
        db.add(ci)

    db.commit()

    log = models.ActivityLog(
        user_id=current_user.id,
        action="created checklist",
        details=f"Checklist for movie {movie_id} with {len(items)} items"
    )
    db.add(log)
    db.commit()

    return {"message": "Checklist created", "checklist_id": checklist.id}


@router.get("/")
def list_checklists(
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    """Admin view all checklists"""
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Only admin can view all checklists")

    checklists = db.query(models.Checklist).all()
    return [
        {
            "id": c.id,
            "movie_id": c.movie_id,
            "created_at": c.created_at,
            "items": [
                {"id": i.id, "description": i.description, "status": i.status}
                for i in c.items
            ]
        }
        for c in checklists
    ]


# ----------- PRODUCTION ENDPOINTS -----------

@router.get("/{movie_id}")
def view_checklist(
    movie_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    """Production can view checklist progress for a movie"""
    if current_user.role != "production":
        raise HTTPException(status_code=403, detail="Only production can view checklists")

    checklist = db.query(models.Checklist).filter(models.Checklist.movie_id == movie_id).first()
    if not checklist:
        raise HTTPException(status_code=404, detail="Checklist not found")

    total = len(checklist.items)
    completed = sum(1 for i in checklist.items if i.status == "completed")

    return {
        "movie_id": movie_id,
        "checklist_id": checklist.id,
        "progress": f"{completed}/{total} completed",
        "items": [
            {"id": i.id, "description": i.description, "status": i.status}
            for i in checklist.items
        ]
    }


# ----------- AUTO UPDATE ON CONTRACT APPROVAL -----------

def update_checklist_on_contract_approval(db: Session, contract: models.Contract):
    """
    When a contract is approved, update the corresponding checklist item if it exists.
    This is called from contracts.py legal_review endpoint.
    """
    if not contract or not contract.title:
        return

    # Find checklist item that matches contract title
    checklist_item = (
        db.query(models.ChecklistItem)
        .filter(models.ChecklistItem.description.ilike(f"%{contract.title}%"))
        .first()
    )

    if checklist_item:
        checklist_item.status = "completed"
        db.commit()

        log = models.ActivityLog(
            user_id=contract.reviewed_by,
            contract_id=contract.id,
            action="checklist updated",
            details=f"Checklist item '{checklist_item.description}' marked completed"
        )
        db.add(log)
        db.commit()
