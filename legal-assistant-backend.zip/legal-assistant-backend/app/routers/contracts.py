# app/routers/contracts.py (Gemini version)
import os
import json
import pdfplumber
import docx
import google.generativeai as genai
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from sqlalchemy.orm import Session
from datetime import datetime
from pydantic import BaseModel, Field, ValidationError
from typing import List, Optional, Dict, Any

from app.database import get_db
from app import models
from app.routers.auth import get_current_user

router = APIRouter(prefix="/contracts", tags=["Contracts"])

UPLOAD_DIR = "uploaded_contracts"
os.makedirs(UPLOAD_DIR, exist_ok=True)

# Configure Gemini
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY")
if not GEMINI_API_KEY:
    raise RuntimeError("❌ GEMINI_API_KEY not found in environment")
genai.configure(api_key=GEMINI_API_KEY)


# --------- Pydantic schema for output ----------
class RedFlag(BaseModel):
    code: Optional[str]
    text: str
    severity: str = Field(..., pattern="^(high|medium|low)$")
    location: Optional[str] = None
    suggested_action: Optional[str] = None

class ExtractedContract(BaseModel):
    parties: List[str] = []
    effective_date: Optional[str] = None
    termination_date: Optional[str] = None
    contract_type: Optional[str] = None
    payment_terms: Optional[str] = None
    obligations: Optional[str] = None
    warranties: Optional[str] = None
    indemnities: Optional[str] = None
    governing_law: Optional[str] = None
    notice_periods: Optional[str] = None
    confidentiality_terms: Optional[str] = None
    other_key_terms: Optional[str] = None
    red_flags: List[RedFlag] = []


# --------- File parsers ----------
def extract_text_from_pdf(path: str) -> str:
    texts = []
    with pdfplumber.open(path) as pdf:
        for page in pdf.pages:
            txt = page.extract_text()
            if txt:
                texts.append(txt)
    return "\n\n".join(texts)

def extract_text_from_docx(path: str) -> str:
    doc = docx.Document(path)
    return "\n\n".join([p.text for p in doc.paragraphs if p.text.strip()])


# --------- Gemini call ----------
def call_llm_analyze_contract(contract_text: str, rules_text: Optional[str] = None) -> Dict[str, Any]:
    model = genai.GenerativeModel("gemini-1.5-flash")

    user_prompt = (
        "You are a legal assistant. Extract structured JSON with key details and red flags from this contract. "
        "The JSON must follow this schema exactly:\n\n"
        "{\n"
        '  "parties": ["Party A", "Party B"],\n'
        '  "effective_date": "...",\n'
        '  "termination_date": "...",\n'
        '  "contract_type": "...",\n'
        '  "payment_terms": "...",\n'
        '  "obligations": "...",\n'
        '  "warranties": "...",\n'
        '  "indemnities": "...",\n'
        '  "governing_law": "...",\n'
        '  "notice_periods": "...",\n'
        '  "confidentiality_terms": "...",\n'
        '  "other_key_terms": "...",\n'
        '  "red_flags": [\n'
        '      {"code":"RG01","text":"...","severity":"high|medium|low","location":"...","suggested_action":"..."}\n'
        "  ]\n"
        "}\n\n"
    )

    if rules_text:
        user_prompt += f"Rules for red flag detection:\n{rules_text}\n\n"

    user_prompt += f"Contract:\n{contract_text[:40000]}"  # cap length

    try:
        response = model.generate_content(user_prompt)
        llm_output = response.text.strip()
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"Gemini request failed: {e}")

    # Try parsing JSON
    try:
        return json.loads(llm_output)
    except json.JSONDecodeError:
        start = llm_output.find("{")
        end = llm_output.rfind("}") + 1
        if start >= 0 and end > start:
            return json.loads(llm_output[start:end])
        raise HTTPException(status_code=502, detail=f"Gemini did not return valid JSON: {llm_output[:500]}")


# --------- Routes ----------
@router.post("/upload")
async def upload_contract(
    title: str = Form(...),
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    if current_user.role != "production":
        raise HTTPException(status_code=403, detail="Only production can upload")

    # Save file
    filename = f"{int(datetime.utcnow().timestamp())}_{file.filename}"
    file_path = os.path.join(UPLOAD_DIR, filename)
    with open(file_path, "wb") as f:
        f.write(await file.read())

    # Extract text
    if file.filename.lower().endswith(".pdf"):
        text = extract_text_from_pdf(file_path)
    elif file.filename.lower().endswith(".docx"):
        text = extract_text_from_docx(file_path)
    else:
        raise HTTPException(status_code=400, detail="Only PDF or DOCX supported")

    # Get rules as plain text
    rules = db.query(models.Rule).all()
    rules_text = "\n".join([f"- {r.rule_name}: {r.description}" for r in rules]) if rules else None

    # Call Gemini
    result = call_llm_analyze_contract(text, rules_text)

    # Validate
    try:
        parsed = ExtractedContract(**result)
    except ValidationError as e:
        raise HTTPException(status_code=502, detail=f"Gemini output invalid: {e}")

    # Save contract
    contract = models.Contract(
        title=title,
        file_path=file_path,
        extracted_text=text,
        red_flags=json.dumps([rf.dict() for rf in parsed.red_flags]),
        status=models.ContractStatus.under_review,
        uploaded_by=current_user.id,
        created_at=datetime.utcnow()
    )
    db.add(contract)
    db.commit()
    db.refresh(contract)

    # Log
    log = models.ActivityLog(
        user_id=current_user.id,
        action="uploaded contract (analyzed)",
        contract_id=contract.id,
        details=f"Gemini extracted {len(parsed.red_flags)} red flags"
    )
    db.add(log)
    db.commit()

    return {
        "contract_id": contract.id,
        "title": contract.title,
        "analysis": parsed.dict(),
        "red_flags_count": len(parsed.red_flags)
    }


# --- SEND TO LEGAL ---
@router.post("/{contract_id}/send-to-legal")
def send_to_legal(
    contract_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    if current_user.role != "production":
        raise HTTPException(status_code=403, detail="Only production can send to legal")

    contract = db.query(models.Contract).filter(models.Contract.id == contract_id).first()
    if not contract:
        raise HTTPException(status_code=404, detail="Contract not found")

    if contract.status != models.ContractStatus.under_review:
        raise HTTPException(status_code=400, detail="Contract must be under_review before sending to legal")

    contract.status = models.ContractStatus.pending_legal_review
    db.commit()

    log = models.ActivityLog(
        user_id=current_user.id,
        action="sent contract to legal",
        contract_id=contract.id,
        details="Production requested legal review"
    )
    db.add(log)
    db.commit()

    return {"message": "Contract sent to legal", "contract_id": contract.id, "status": contract.status.value}


# --- LEGAL REVIEW (approve/reject) ---
@router.post("/{contract_id}/legal-review")
def legal_review(
    contract_id: int,
    decision: str = Form(..., regex="^(approve|reject)$"),
    comments: Optional[str] = Form(None),
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    if current_user.role != "legal":
        raise HTTPException(status_code=403, detail="Only legal team can review contracts")

    contract = db.query(models.Contract).filter(models.Contract.id == contract_id).first()
    if not contract:
        raise HTTPException(status_code=404, detail="Contract not found")

    if contract.status != models.ContractStatus.pending_legal_review:
        raise HTTPException(status_code=400, detail="Contract not awaiting legal review")

    if decision == "approve":
        contract.status = models.ContractStatus.approved
    else:
        contract.status = models.ContractStatus.rejected

    db.commit()

    log = models.ActivityLog(
        user_id=current_user.id,
        action=f"legal {decision}d contract",
        contract_id=contract.id,
        details=comments or "No comments"
    )
    db.add(log)
    db.commit()

    return {
        "message": f"Contract {decision}d by legal",
        "contract_id": contract.id,
        "status": contract.status.value,
        "comments": comments
    }
