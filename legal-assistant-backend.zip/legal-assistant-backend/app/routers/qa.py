import os
import json
from datetime import datetime
from fastapi import APIRouter, Depends, UploadFile, File, HTTPException, Form
from sqlalchemy.orm import Session
from typing import List
import pdfplumber, docx
import google.generativeai as genai
import chromadb

from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.vectorstores import Chroma
from langchain.prompts import ChatPromptTemplate
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_google_genai import GoogleGenerativeAIEmbeddings


from app.database import get_db
from app import models
from app.routers.auth import get_current_user

router = APIRouter(prefix="/qa", tags=["Q&A / Signed Contracts"])

# --- Gemini setup ---
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY")
if not GEMINI_API_KEY:
    raise RuntimeError("❌ GEMINI_API_KEY not set")
genai.configure(api_key=GEMINI_API_KEY)

# --- LangChain setup ---
embeddings = GoogleGenerativeAIEmbeddings(model="models/embedding-001", google_api_key=GEMINI_API_KEY)

text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=800,
    chunk_overlap=100,
    separators=["\n\n", "\n", ".", " ", ""]
)

vectorstore = Chroma(
    collection_name="signed_contracts",
    persist_directory="chroma_db",
    embedding_function=embeddings
)

UPLOAD_DIR = "signed_contracts"
os.makedirs(UPLOAD_DIR, exist_ok=True)

# ---------- Helpers ----------
def extract_text(file_path: str, filename: str) -> str:
    if filename.lower().endswith(".pdf"):
        with pdfplumber.open(file_path) as pdf:
            return "\n\n".join([page.extract_text() or "" for page in pdf.pages])
    elif filename.lower().endswith(".docx"):
        doc = docx.Document(file_path)
        return "\n\n".join([p.text for p in doc.paragraphs if p.text.strip()])
    else:
        raise HTTPException(status_code=400, detail="Only PDF/DOCX allowed")


def call_llm_for_checklist_mapping(contract_text: str, checklist_items: List[str]) -> List[str]:
    """Ask Gemini which checklist items this contract fulfills"""
    model = genai.GenerativeModel("gemini-1.5-flash")

    prompt = (
        "You are an assistant that maps signed contracts to checklist items.\n"
        "Here is the checklist:\n"
        + "\n".join(f"- {item}" for item in checklist_items)
        + "\n\nSigned contract text:\n"
        f"{contract_text[:40000]}\n\n"
        "Output a JSON list of checklist item names that are satisfied by this signed contract."
    )

    response = model.generate_content(prompt)
    try:
        result = json.loads(response.text.strip())
        if not isinstance(result, list):
            raise ValueError("Expected a list")
        return result
    except Exception:
        return []


# ---------- Routes ----------
@router.post("/upload-signed")
async def upload_signed_contract(
    movie_id: int = Form(...),
    title: str = Form(...),
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    if current_user.role != "production":
        raise HTTPException(status_code=403, detail="Only production can upload signed contracts")

    # Save file
    filename = f"{int(datetime.utcnow().timestamp())}_{file.filename}"
    file_path = os.path.join(UPLOAD_DIR, filename)
    with open(file_path, "wb") as f:
        f.write(await file.read())

    # Extract text
    contract_text = extract_text(file_path, file.filename)

    # Save in DB
    signed_contract = models.SignedContract(
        movie_id=movie_id,
        title=title,
        file_path=file_path,
        extracted_text=contract_text,
        uploaded_by=current_user.id,
        created_at=datetime.utcnow()
    )
    db.add(signed_contract)
    db.commit()
    db.refresh(signed_contract)

    # Split into chunks
    chunks = text_splitter.split_text(contract_text)

    # Store in ChromaDB with embeddings
    metas = [{"movie_id": movie_id, "title": title, "chunk": i} for i in range(len(chunks))]
    vectorstore.add_texts(chunks, metadatas=metas, ids=[f"{signed_contract.id}_{i}" for i in range(len(chunks))])
    vectorstore.persist()

    # Load checklist for this movie
    checklist = db.query(models.Checklist).filter(models.Checklist.movie_id == movie_id).first()
    if not checklist:
        raise HTTPException(status_code=404, detail="No checklist for this movie")

    checklist_items = [i.description for i in checklist.items]

    # Use LLM to decide which checklist items this contract fulfills
    matched_items = call_llm_for_checklist_mapping(contract_text, checklist_items)

    updated_items = []
    for desc in matched_items:
        item = (
            db.query(models.ChecklistItem)
            .filter(models.ChecklistItem.checklist_id == checklist.id)
            .filter(models.ChecklistItem.description.ilike(f"%{desc}%"))
            .first()
        )
        if item and item.status != "completed":
            item.status = "completed"
            db.commit()
            updated_items.append(item.description)

            # Log activity
            log = models.ActivityLog(
                user_id=current_user.id,
                action="signed contract mapped to checklist",
                contract_id=signed_contract.id,
                details=f"Checklist item '{item.description}' marked completed"
            )
            db.add(log)
            db.commit()

    return {
        "message": "Signed contract saved and analyzed",
        "contract_id": signed_contract.id,
        "matched_checklist_items": updated_items
    }


@router.post("/ask")
def ask_question(
    movie_id: int,
    question: str = Form(...),
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    if current_user.role != "production":
        raise HTTPException(status_code=403, detail="Only production can ask Q&A")

    retriever = vectorstore.as_retriever(search_kwargs={"k": 3, "filter": {"movie_id": movie_id}})
    docs = retriever.get_relevant_documents(question)

    if not docs:
        return {"answer": "No relevant information found in signed contracts."}

    context = "\n\n".join([d.page_content for d in docs])

    llm = ChatGoogleGenerativeAI(model="gemini-1.5-flash", google_api_key=GEMINI_API_KEY, temperature=0.2)

    prompt_template = ChatPromptTemplate.from_messages([
        ("system", "You are a legal assistant. Use the provided contract excerpts to answer clearly."),
        ("human", "Context:\n{context}\n\nQuestion: {question}\nAnswer:")
    ])

    chain = prompt_template | llm
    response = chain.invoke({"context": context, "question": question})

    return {"answer": response.content, "sources": [d.metadata for d in docs]}
