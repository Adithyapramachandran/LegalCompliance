# app/routers/activity.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app import models
from app.routers.auth import get_current_user

router = APIRouter(prefix="/activity", tags=["Activity Logs"])


# ✅ Get all activity logs (Admin only)
@router.get("/")
def get_activity_logs(
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")

    logs = db.query(models.ActivityLog).order_by(models.ActivityLog.timestamp.desc()).all()
    return [
        {
            "id": log.id,
            "user_id": log.user_id,
            "contract_id": log.contract_id,
            "action": log.action,
            "details": log.details,
            "timestamp": log.timestamp,
        }
        for log in logs
    ]


# ✅ Get logs for a specific user (Admin only)
@router.get("/user/{user_id}")
def get_user_activity(
    user_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")

    logs = db.query(models.ActivityLog).filter(models.ActivityLog.user_id == user_id).all()
    return [
        {
            "id": log.id,
            "contract_id": log.contract_id,
            "action": log.action,
            "details": log.details,
            "timestamp": log.timestamp,
        }
        for log in logs
    ]


# ✅ Get logs for a specific contract (Admin only)
@router.get("/contract/{contract_id}")
def get_contract_activity(
    contract_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")

    logs = db.query(models.ActivityLog).filter(models.ActivityLog.contract_id == contract_id).all()
    return [
        {
            "id": log.id,
            "user_id": log.user_id,
            "action": log.action,
            "details": log.details,
            "timestamp": log.timestamp,
        }
        for log in logs
    ]
