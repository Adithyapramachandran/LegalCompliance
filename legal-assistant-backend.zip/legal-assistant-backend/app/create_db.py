# app/create_db.py

import os
import enum
from datetime import datetime
from sqlalchemy import (
    create_engine, Column, Integer, String, Text, DateTime, ForeignKey, Enum, Boolean
)
from sqlalchemy.orm import declarative_base, relationship

# Define DB path
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, "legal_assistant.db")
DATABASE_URL = f"sqlite:///{DB_PATH}"

# Setup engine & base
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
Base = declarative_base()

# Enum for roles
class UserRole(enum.Enum):
    admin = "admin"
    production = "production"
    legal = "legal"

# Enum for contract status
class ContractStatus(enum.Enum):
    draft = "draft"
    under_review = "under_review"
    sent_to_legal = "sent_to_legal"
    approved = "approved"
    rejected = "rejected"

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, nullable=False)
    email = Column(String(50), unique=True, nullable=False)
    phone_number = Column(Integer, unique=True, nullable=False)
    company_name = Column(String(100), nullable=False)
    created_date = Column(DateTime, default=datetime.utcnow)
    password_hash = Column(String(255), nullable=False)
    role = Column(Enum(UserRole), nullable=False)

    # Relationships
    contracts = relationship("Contract", back_populates="uploaded_by_user")
    activities = relationship("ActivityLog", back_populates="user")

class Contract(Base):
    __tablename__ = "contracts"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(100), nullable=False)
    file_path = Column(String(255), nullable=False)
    extracted_text = Column(Text)  # raw text extracted from file
    red_flags = Column(Text)  # JSON string or comma-separated
    status = Column(Enum(ContractStatus), default=ContractStatus.draft)
    uploaded_by = Column(Integer, ForeignKey("users.id"))
    reviewed_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    uploaded_by_user = relationship("User", foreign_keys=[uploaded_by], back_populates="contracts")
    reviewed_by_user = relationship("User", foreign_keys=[reviewed_by])

class ActivityLog(Base):
    __tablename__ = "activity_log"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    action = Column(String(255), nullable=False)  # e.g., "uploaded contract", "approved contract"
    contract_id = Column(Integer, ForeignKey("contracts.id"), nullable=True)
    details = Column(Text)  # extra info if needed
    timestamp = Column(DateTime, default=datetime.utcnow)

    # Relationship
    user = relationship("User", back_populates="activities")

class Rule(Base):
    __tablename__ = "rules"

    rule_id = Column(String, primary_key=True, index=True)
    rule_name = Column(Text, nullable=False)
    description = Column(Text, nullable=False)
    mandatory = Column(Boolean)
    example_text = Column(Text, nullable=False)

class ChecklistItem(Base):
    __tablename__ = "checklist_items"

    id = Column(Integer, primary_key=True, index=True)
    movie_title = Column(String(255), nullable=False) 
    doc_type = Column(String(100), nullable=False)   # e.g., "Actor Contract"
    description = Column(String(255))
    mandatory = Column(Boolean, default=True)
    status = Column(String(50), default="pending")   # "pending" | "completed"

    # Optional link to contract
    contract_id = Column(Integer, ForeignKey("contracts.id"), nullable=True)

    # Relationships
    contract = relationship("Contract", foreign_keys=[contract_id])

class SignedContract(Base):
    __tablename__ = "signed_contracts"

    id = Column(Integer, primary_key=True, index=True)
    movie_name = Column(String, nullable=False)
    title = Column(String, nullable=False)
    file_path = Column(String, nullable=False)
    extracted_text = Column(Text, nullable=True)
    uploaded_by = Column(Integer, ForeignKey("users.id"))
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    uploader = relationship("User", foreign_keys=[uploaded_by])


# Create tables
if __name__ == "__main__":
    print(f"👉 Creating DB at: {DB_PATH}")
    from app.models import User, Contract, ActivityLog, Rule, ChecklistItem
    Base.metadata.create_all(bind=engine)
    print("✅ legal_assistant.db created with tables!")
