# app/main.py
from fastapi import FastAPI
from contextlib import asynccontextmanager
from app.database import init_db
from app.routers import auth , users ,contracts ,checklists ,qa ,activity  # import router

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    yield

app = FastAPI(
    title="Legal Assistant Backend",
    description="Backend API for Legal Assistant app",
    version="0.1",
    lifespan=lifespan
)

# Root test route
@app.get("/")
def home():
    return {"message": "Legal Assistant Backend Running 🚀"}


# Register routers
app.include_router(auth.router)
app.include_router(users.router)
app.include_router(contracts.router)
app.include_router(checklists.router)  # Movie checklists
app.include_router(qa.router)          # Signed contract storage + Q&A
app.include_router(activity.router)  
