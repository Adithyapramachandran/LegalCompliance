# database.py
import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

# Absolute path to ensure DB is created in project root
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, "legal_assistant.db")
DATABASE_URL = f"sqlite:///{DB_PATH}"

# SQLAlchemy engine and session
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()

# Initialize database and tables
def init_db():
    from app.models import User, Contract, ActivityLog, Rule
    Base.metadata.create_all(bind=engine)
    print(f"✅ Database initialized at {DB_PATH}")

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()