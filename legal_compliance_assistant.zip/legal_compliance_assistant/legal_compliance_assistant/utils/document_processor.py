import os
import PyPDF2
from docx import Document
import re

class DocumentProcessor:
    def __init__(self):
        self.compliance_rules = self.load_compliance_rules()
    
    def load_compliance_rules(self):
        """Load compliance rules for film production"""
        return {
            "labor_laws": [
                "overtime pay after 8 hours",
                "minimum wage requirements", 
                "meal break violations",
                "rest period compliance"
            ],
            "safety_regulations": [
                "safety protocol adherence",
                "insurance requirements",
                "location safety standards"
            ],
            "intellectual_property": [
                "copyright infringement",
                "trademark violation", 
                "right of publicity"
            ],
            "union_requirements": [
                "union scale payments",
                "working condition standards",
                "credit requirements"
            ]
        }
    
    def extract_text_from_pdf(self, file_path):
        """Extract text from PDF files"""
        try:
            with open(file_path, 'rb') as file:
                reader = PyPDF2.PdfReader(file)
                text = ""
                for page in reader.pages:
                    text += page.extract_text()
                return text
        except Exception as e:
            return f"Error reading PDF: {str(e)}"
    
    def extract_text_from_docx(self, file_path):
        """Extract text from DOCX files"""
        try:
            doc = Document(file_path)
            text = ""
            for paragraph in doc.paragraphs:
                text += paragraph.text + "\n"
            return text
        except Exception as e:
            return f"Error reading DOCX: {str(e)}"
    
    def extract_text_from_txt(self, file_path):
        """Extract text from TXT files"""
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                return file.read()
        except Exception as e:
            return f"Error reading TXT: {str(e)}"
    
    def analyze_contract(self, file_path):
        """Analyze contract for compliance issues"""
        # For demo purposes, return mock data
        # In real implementation, you would process the actual file
        
        return {
            'summary': 'This contract appears to be a standard actor agreement between Production Co and John Doe for the film "Sunset Dreams". Key terms include 30-day shooting schedule, $500 daily rate, and standard credit provisions.',
            'red_flags': [
                'No overtime provisions detected',
                'Unlimited liability clause found', 
                'Ambiguous termination terms',
                'Missing safety protocol references'
            ],
            'key_terms': {
                'Parties': 'Production Co and John Doe',
                'Payment Terms': '$500 per day',
                'Duration': '30 shooting days',
                'Termination': 'Producer may terminate with 7 days notice',
                'Governing Law': 'California'
            },
            'recommendations': [
                'Add specific overtime compensation clauses',
                'Limit liability to direct damages only',
                'Include explicit safety protocol compliance',
                'Specify union compliance if applicable'
            ]
        }
    
    def generate_summary(self, text):
        """Generate contract summary"""
        return "Contract summary generated based on analysis of key terms and obligations."
    
    def check_red_flags(self, text):
        """Check for compliance red flags"""
        return ["Sample red flag: No overtime provisions"]
    
    def extract_key_terms(self, text):
        """Extract key contract terms"""
        return {
            "Parties": "Extracted from contract",
            "Term/Duration": "30 days", 
            "Payment Terms": "$500/day",
            "Termination Clause": "Present",
            "Governing Law": "California"
        }
    
    def generate_recommendations(self, red_flags):
        """Generate recommendations based on red flags"""
        return ["Consult with legal team for comprehensive review"]