class ChatHandler:
    def __init__(self):
        pass
    
    def get_response(self, question, documents):
        """Generate AI response based on question and document context"""
        
        responses = {
            "compliance": "Based on your documents, I've identified several compliance considerations. Always ensure contracts include overtime provisions, safety protocols, and proper insurance clauses.",
            "contract": "Reviewing your contract history, I recommend checking termination clauses and liability limitations. Film production contracts should clearly define intellectual property rights.",
            "payment": "Payment terms should align with industry standards and union requirements. Typical rates vary by role and experience level.",
            "rights": "Intellectual property rights need clear definition in all production agreements. Ensure copyright and trademark usage is properly licensed.",
            "safety": "Safety protocols must comply with OSHA and industry standards. Location agreements should include emergency procedures."
        }
        
        # Simple keyword matching for demo
        if any(word in question.lower() for word in ['compliance', 'rule', 'regulation']):
            response = responses['compliance']
        elif any(word in question.lower() for word in ['contract', 'agreement']):
            response = responses['contract']
        elif any(word in question.lower() for word in ['payment', 'fee', 'money']):
            response = responses['payment']
        elif any(word in question.lower() for word in ['right', 'copyright', 'ip']):
            response = responses['rights']
        elif any(word in question.lower() for word in ['safety', 'insurance']):
            response = responses['safety']
        else:
            response = "I've analyzed your query in the context of legal compliance for film production. Based on standard industry practices, I recommend consulting with specialized legal counsel for production-specific advice."
        
        return response
    
    def get_relevant_context(self, question, documents):
        """Extract relevant context from documents based on question"""
        return documents