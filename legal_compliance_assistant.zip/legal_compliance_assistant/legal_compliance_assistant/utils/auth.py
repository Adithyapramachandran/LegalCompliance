import streamlit as st
import hashlib
import sqlite3
import re
import datetime
from typing import Tuple, Optional

class AuthSystem:
    def __init__(self):
        self.init_auth_db()
    
    def init_auth_db(self):
        """Initialize authentication database with error handling"""
        try:
            conn = sqlite3.connect('users.db')
            c = conn.cursor()
            c.execute('''
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT UNIQUE NOT NULL,
                    password TEXT NOT NULL,
                    email TEXT UNIQUE,
                    company_name TEXT,
                    created_date TEXT
                )
            ''')
            conn.commit()
            conn.close()
            return True, "Database initialized successfully"
        except sqlite3.Error as e:
            return False, f"Database error: {str(e)}"
        except Exception as e:
            return False, f"Unexpected error initializing database: {str(e)}"
    
    def validate_username(self, username: str) -> Tuple[bool, str]:
        """Validate username format and availability"""
        try:
            # Check if username is provided
            if not username or username.strip() == "":
                return False, "Username is required"
            
            username = username.strip()
            
            # Check length
            if len(username) < 3:
                return False, "Username must be at least 3 characters long"
            if len(username) > 50:
                return False, "Username cannot exceed 50 characters"
            
            # Check allowed characters (alphanumeric, underscores, hyphens)
            if not re.match(r'^[a-zA-Z0-9_-]+$', username):
                return False, "Username can only contain letters, numbers, underscores, and hyphens"
            
            # Check if username starts with letter or number
            if not username[0].isalnum():
                return False, "Username must start with a letter or number"
            
            # Check if username already exists
            conn = sqlite3.connect('users.db')
            c = conn.cursor()
            c.execute('SELECT username FROM users WHERE username = ?', (username,))
            existing_user = c.fetchone()
            conn.close()
            
            if existing_user:
                return False, "Username already exists. Please choose a different one."
            
            return True, "Username is valid"
            
        except sqlite3.Error as e:
            return False, f"Database error while checking username: {str(e)}"
        except Exception as e:
            return False, f"Unexpected error validating username: {str(e)}"
    
    def validate_email(self, email: str) -> Tuple[bool, str]:
        """Validate email format and uniqueness"""
        try:
            # Check if email is provided
            if not email or email.strip() == "":
                return False, "Email is required"
            
            email = email.strip().lower()
            
            # Basic email format validation
            email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
            if not re.match(email_pattern, email):
                return False, "Please enter a valid email address"
            
            # Check email length
            if len(email) > 100:
                return False, "Email address is too long"
            
            # Check if email already exists
            conn = sqlite3.connect('users.db')
            c = conn.cursor()
            c.execute('SELECT email FROM users WHERE email = ?', (email,))
            existing_email = c.fetchone()
            conn.close()
            
            if existing_email:
                return False, "Email address is already registered. Please use a different email or login."
            
            return True, "Email is valid"
            
        except sqlite3.Error as e:
            return False, f"Database error while checking email: {str(e)}"
        except Exception as e:
            return False, f"Unexpected error validating email: {str(e)}"
    
    def validate_password(self, password: str, confirm_password: str) -> Tuple[bool, str]:
        """Validate password strength and confirmation"""
        try:
            # Check if passwords are provided
            if not password or password.strip() == "":
                return False, "Password is required"
            
            if not confirm_password or confirm_password.strip() == "":
                return False, "Please confirm your password"
            
            # Check minimum length
            if len(password) < 8:
                return False, "Password must be at least 8 characters long"
            
            # Check maximum length
            if len(password) > 100:
                return False, "Password is too long"
            
            # Check password strength
            has_upper = any(char.isupper() for char in password)
            has_lower = any(char.islower() for char in password)
            has_digit = any(char.isdigit() for char in password)
            has_special = any(not char.isalnum() for char in password)
            
            strength_issues = []
            if not has_upper:
                strength_issues.append("uppercase letter")
            if not has_lower:
                strength_issues.append("lowercase letter")
            if not has_digit:
                strength_issues.append("digit")
            if not has_special:
                strength_issues.append("special character")
            
            if strength_issues:
                return False, f"Password should contain at least one {', '.join(strength_issues)}"
            
            # Check if passwords match
            if password != confirm_password:
                return False, "Passwords do not match"
            
            return True, "Password is valid"
            
        except Exception as e:
            return False, f"Unexpected error validating password: {str(e)}"
    
    def validate_company_name(self, company_name: str) -> Tuple[bool, str]:
        """Validate company name"""
        try:
            if not company_name or company_name.strip() == "":
                return False, "Company name is required"
            
            company_name = company_name.strip()
            
            if len(company_name) < 2:
                return False, "Company name is too short"
            
            if len(company_name) > 100:
                return False, "Company name is too long"
            
            # Check for potentially malicious content
            if re.search(r'[<>{}[\]~`]', company_name):
                return False, "Company name contains invalid characters"
            
            return True, "Company name is valid"
            
        except Exception as e:
            return False, f"Unexpected error validating company name: {str(e)}"
    
    def hash_password(self, password: str) -> str:
        """Hash password for security with error handling"""
        try:
            return hashlib.sha256(password.encode()).hexdigest()
        except Exception as e:
            raise Exception(f"Error hashing password: {str(e)}")
    
    def register_user(self, username: str, password: str, confirm_password: str, email: str, company_name: str) -> Tuple[bool, str]:
        """Register a new user with comprehensive validation"""
        try:
            # Step 1: Validate all inputs
            validations = [
                self.validate_username(username),
                self.validate_email(email),
                self.validate_password(password, confirm_password),
                self.validate_company_name(company_name)
            ]
            
            # Check if any validation failed
            for is_valid, message in validations:
                if not is_valid:
                    return False, message
            
            # Step 2: Hash password
            try:
                hashed_password = self.hash_password(password)
            except Exception as e:
                return False, f"Security error: {str(e)}"
            
            # Step 3: Save to database
            conn = None
            try:
                conn = sqlite3.connect('users.db')
                c = conn.cursor()
                
                c.execute('''
                    INSERT INTO users (username, password, email, company_name, created_date)
                    VALUES (?, ?, ?, ?, ?)
                ''', (username.strip(), hashed_password, email.strip().lower(), company_name.strip(), datetime.datetime.now()))
                
                conn.commit()
                
                # Verify the user was created
                c.execute('SELECT id FROM users WHERE username = ?', (username,))
                user_id = c.fetchone()
                
                if user_id:
                    return True, "Registration successful! You can now login to your account."
                else:
                    return False, "Registration failed: User was not created properly."
                    
            except sqlite3.IntegrityError as e:
                # This shouldn't happen due to prior validation, but handle it anyway
                error_msg = str(e).lower()
                if "username" in error_msg:
                    return False, "Username already exists. Please choose a different username."
                elif "email" in error_msg:
                    return False, "Email address is already registered. Please use a different email."
                else:
                    return False, "Registration failed due to database constraints."
                    
            except sqlite3.Error as e:
                return False, f"Database error during registration: {str(e)}"
                
            finally:
                if conn:
                    conn.close()
                    
        except Exception as e:
            return False, f"Unexpected error during registration: {str(e)}"
    
    def login_user(self, username: str, password: str) -> Tuple[bool, Optional[tuple]]:
        """Authenticate user with error handling"""
        try:
            # Basic input validation
            if not username or not password:
                return False, "Username and password are required"
            
            # Hash the provided password
            try:
                hashed_password = self.hash_password(password)
            except Exception as e:
                return False, f"Security error: {str(e)}"
            
            conn = None
            try:
                conn = sqlite3.connect('users.db')
                c = conn.cursor()
                
                c.execute('''
                    SELECT * FROM users 
                    WHERE username = ? AND password = ?
                ''', (username.strip(), hashed_password))
                
                user = c.fetchone()
                
                if user:
                    return True, user
                else:
                    return False, "Invalid username or password"
                    
            except sqlite3.Error as e:
                return False, f"Database error during login: {str(e)}"
                
            finally:
                if conn:
                    conn.close()
                    
        except Exception as e:
            return False, f"Unexpected error during login: {str(e)}"
    
    def get_user_data(self, username: str) -> Optional[tuple]:
        """Get user data by username with error handling"""
        try:
            conn = sqlite3.connect('users.db')
            c = conn.cursor()
            c.execute('SELECT * FROM users WHERE username = ?', (username,))
            user = c.fetchone()
            conn.close()
            return user
        except sqlite3.Error as e:
            st.error(f"Error retrieving user data: {str(e)}")
            return None
        except Exception as e:
            st.error(f"Unexpected error: {str(e)}")
            return None