import streamlit as st
import sqlite3
import hashlib
import datetime
import re
import os
import tempfile

# Authentication System (keep this part the same)
class AuthSystem:
    def __init__(self):
        self.init_auth_db()
    
    def init_auth_db(self):
        """Initialize authentication database with schema migration"""
        conn = sqlite3.connect('users.db')
        c = conn.cursor()
        
        # Create table if it doesn't exist
        c.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                email TEXT,
                phone_number TEXT,
                company_name TEXT,
                created_date TEXT,
                role TEXT DEFAULT 'user'
            )
        ''')
        
        # Check if phone_number column exists, if not add it
        try:
            c.execute("SELECT phone_number FROM users LIMIT 1")
        except sqlite3.OperationalError:
            c.execute('ALTER TABLE users ADD COLUMN phone_number TEXT')
        
        # Check if role column exists, if not add it
        try:
            c.execute("SELECT role FROM users LIMIT 1")
        except sqlite3.OperationalError:
            c.execute('ALTER TABLE users ADD COLUMN role TEXT DEFAULT "user"')
        
        # Create default admin user if it doesn't exist
        c.execute('SELECT * FROM users WHERE username = "admin"')
        if not c.fetchone():
            hashed_password = hashlib.sha256("admin123".encode()).hexdigest()
            c.execute('''
                INSERT INTO users (username, password, email, phone_number, company_name, created_date, role)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', ('admin', hashed_password, 'admin@filmproduction.com', '1234567890', 'Film Production Admin', datetime.datetime.now(), 'admin'))
        
        conn.commit()
        conn.close()
    
    def hash_password(self, password):
        """Hash password for security"""
        return hashlib.sha256(password.encode()).hexdigest()
    
    def validate_email(self, email):
        """Validate email format"""
        try:
            if not email or email.strip() == "":
                return False, "Email is required"
            
            email = email.strip().lower()
            pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
            
            if not re.match(pattern, email):
                return False, "Please enter a valid email address"
            
            if len(email) > 100:
                return False, "Email address is too long"
            
            return True, "Email is valid"
        except Exception as e:
            return False, f"Error validating email: {str(e)}"
    
    def validate_phone_number(self, phone_number):
        """Validate phone number format"""
        try:
            if not phone_number or phone_number.strip() == "":
                return False, "Phone number is required"
            
            phone_number = phone_number.strip()
            cleaned_phone = re.sub(r'[\s\-\(\)\+]', '', phone_number)
            
            if not cleaned_phone.isdigit():
                return False, "Phone number should contain only digits"
            
            if len(cleaned_phone) < 10:
                return False, "Phone number is too short"
            
            if len(cleaned_phone) > 15:
                return False, "Phone number is too long"
            
            return True, "Phone number is valid"
        except Exception as e:
            return False, f"Error validating phone number: {str(e)}"
    
    def validate_username(self, username):
        """Validate username"""
        try:
            if not username or username.strip() == "":
                return False, "Username is required"
            
            username = username.strip()
            
            if len(username) < 3:
                return False, "Username must be at least 3 characters long"
            
            if len(username) > 30:
                return False, "Username cannot exceed 30 characters"
            
            if not re.match(r'^[a-zA-Z0-9_-]+$', username):
                return False, "Username can only contain letters, numbers, underscores, and hyphens"
            
            # Check if username already exists
            conn = sqlite3.connect('users.db')
            c = conn.cursor()
            c.execute('SELECT username FROM users WHERE username = ?', (username,))
            existing_user = c.fetchone()
            conn.close()
            
            if existing_user:
                return False, "Username already exists"
            
            return True, "Username is valid"
        except Exception as e:
            return False, f"Error validating username: {str(e)}"
    
    def validate_company_name(self, company_name):
        """Validate company name"""
        try:
            if not company_name or company_name.strip() == "":
                return False, "Company name is required"
            
            company_name = company_name.strip()
            
            if len(company_name) < 2:
                return False, "Company name is too short"
            
            if len(company_name) > 100:
                return False, "Company name is too long"
            
            return True, "Company name is valid"
        except Exception as e:
            return False, f"Error validating company name: {str(e)}"
    
    def register_user(self, username, password, confirm_password, email, phone_number, company_name, role="user"):
        """Register a new user with comprehensive validation"""
        try:
            # Validate all inputs
            validations = [
                self.validate_username(username),
                self.validate_email(email),
                self.validate_phone_number(phone_number),
                self.validate_company_name(company_name)
            ]
            
            # Check password separately
            password_valid, password_message = self.validate_password(password, confirm_password)
            if not password_valid:
                return False, password_message
            
            # Check if any validation failed
            for is_valid, message in validations:
                if not is_valid:
                    return False, message
            
            # Hash password
            hashed_password = self.hash_password(password)
            
            # Clean phone number
            cleaned_phone = re.sub(r'[\s\-\(\)\+]', '', phone_number.strip())
            
            # Save to database
            conn = sqlite3.connect('users.db')
            c = conn.cursor()
            
            c.execute('''
                INSERT INTO users (username, password, email, phone_number, company_name, created_date, role)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (username.strip(), hashed_password, email.strip().lower(), cleaned_phone, company_name.strip(), datetime.datetime.now(), role))
            
            conn.commit()
            conn.close()
            
            return True, "Registration successful! You can now login."
            
        except sqlite3.IntegrityError as e:
            error_msg = str(e).lower()
            if "username" in error_msg:
                return False, "Username already exists"
            elif "email" in error_msg:
                return False, "Email address is already registered"
            else:
                return False, "Registration failed due to database constraints"
        except Exception as e:
            return False, f"Registration failed: {str(e)}"
    
    def validate_password(self, password, confirm_password):
        """Validate password strength and confirmation"""
        try:
            if not password or password.strip() == "":
                return False, "Password is required"
            
            if not confirm_password or confirm_password.strip() == "":
                return False, "Please confirm your password"
            
            if len(password) < 8:
                return False, "Password must be at least 8 characters long"
            
            if len(password) > 100:
                return False, "Password is too long"
            
            # Check password strength
            has_upper = any(char.isupper() for char in password)
            has_lower = any(char.islower() for char in password)
            has_digit = any(char.isdigit() for char in password)
            has_special = any(not char.isalnum() for char in password)
            
            strength_issues = []
            if not has_upper:
                strength_issues.append("uppercase letter")
            if not has_lower:
                strength_issues.append("lowercase letter")
            if not has_digit:
                strength_issues.append("digit")
            if not has_special:
                strength_issues.append("special character")
            
            if strength_issues:
                return False, f"Password should contain at least one {', '.join(strength_issues)}"
            
            if password != confirm_password:
                return False, "Passwords do not match"
            
            return True, "Password is valid"
        except Exception as e:
            return False, f"Error validating password: {str(e)}"
    
    def login_user(self, username, password):
        """Authenticate user"""
        try:
            if not username or not password:
                return False, "Username and password are required"
            
            hashed_password = self.hash_password(password)
            conn = sqlite3.connect('users.db')
            c = conn.cursor()
            
            c.execute('SELECT * FROM users WHERE username = ? AND password = ?', (username.strip(), hashed_password))
            user = c.fetchone()
            conn.close()
            
            if user:
                return True, user
            else:
                return False, "Invalid username or password"
        except Exception as e:
            return False, f"Login failed: {str(e)}"

# Simple mock classes
class DocumentProcessor:
    def analyze_contract(self, file_path):
        return {
            'summary': 'Demo contract analysis complete.',
            'red_flags': ['🚨 No overtime provisions', '🚨 Unlimited liability clause'],
            'key_terms': {'Parties': 'Production Co and John Doe', 'Payment': '$500 per day'},
            'recommendations': ['✅ Add overtime clauses', '✅ Limit liability']
        }

class ChatHandler:
    def get_response(self, question, documents):
        return "As your AI legal assistant, I specialize in film production compliance."

class ContractTemplates:
    def get_template(self, template_type):
        templates = {
            "Actor Agreement": "ACTOR AGREEMENT TEMPLATE...",
            "Location Release": "LOCATION RELEASE TEMPLATE...",
            "Crew Agreement": "CREW AGREEMENT TEMPLATE..."
        }
        return templates.get(template_type, "Template not available.")

# Main Application
class LegalComplianceApp:
    def __init__(self):
        self.auth_system = AuthSystem()
        self.document_processor = DocumentProcessor()
        self.chat_handler = ChatHandler()
        self.templates = ContractTemplates()
        self.init_database()
    
    def init_database(self):
        """Initialize main database with proper schema migration"""
        conn = sqlite3.connect('legal_docs.db')
        c = conn.cursor()
        
        # Create signed_contracts table if it doesn't exist
        c.execute('''
            CREATE TABLE IF NOT EXISTS signed_contracts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                filename TEXT NOT NULL,
                upload_date TEXT NOT NULL,
                username TEXT NOT NULL,
                file_path TEXT NOT NULL,
                file_size INTEGER,
                file_type TEXT,
                UNIQUE(username, filename)
            )
        ''')
        
        conn.commit()
        conn.close()
        print("✅ Database initialized with correct schema")

    def is_admin_user(self):
        """Check if current user is admin"""
        try:
            if not st.session_state.get('logged_in'):
                return False
            
            conn = sqlite3.connect('users.db')
            c = conn.cursor()
            
            c.execute('SELECT role FROM users WHERE username = ?', (st.session_state.username,))
            result = c.fetchone()
            conn.close()
            
            return result and result[0] == 'admin'
        except:
            return False

    def save_signed_contract(self, filename, username, file_content, file_type):
        """Save signed contract to database and file system"""
        try:
            # Create upload directory if it doesn't exist
            upload_dir = "data/signed_contracts"
            if not os.path.exists(upload_dir):
                os.makedirs(upload_dir, exist_ok=True)
            
            file_path = os.path.join(upload_dir, filename)
            file_size = len(file_content)
            
            # Check if file already exists for this user
            conn = sqlite3.connect('legal_docs.db')
            c = conn.cursor()
            c.execute('SELECT id FROM signed_contracts WHERE username = ? AND filename = ?', (username, filename))
            existing_file = c.fetchone()
            
            if existing_file:
                conn.close()
                return False, f"Contract '{filename}' has already been uploaded."
            
            # Save file to filesystem
            with open(file_path, "wb") as f:
                f.write(file_content)
            
            # Save to database
            c.execute('''
                INSERT INTO signed_contracts (filename, upload_date, username, file_path, file_size, file_type)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (filename, datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'), username, file_path, file_size, file_type))
            
            conn.commit()
            conn.close()
            return True, f"Contract '{filename}' uploaded successfully!"
            
        except sqlite3.IntegrityError:
            return False, f"Contract '{filename}' already exists in your storage."
        except Exception as e:
            # Clean up file if database operation failed
            if os.path.exists(file_path):
                os.remove(file_path)
            return False, f"Error saving contract: {str(e)}"

    def get_user_signed_contracts(self, username):
        """Get all signed contracts for a specific user"""
        try:
            conn = sqlite3.connect('legal_docs.db')
            c = conn.cursor()
            
            c.execute('''
                SELECT filename, upload_date, file_size, file_type 
                FROM signed_contracts 
                WHERE username = ? 
                ORDER BY upload_date DESC
            ''', (username,))
            
            contracts = c.fetchall()
            conn.close()
            return contracts
        except Exception as e:
            print(f"Error retrieving contracts: {e}")
            return []

    def delete_signed_contract(self, filename, username):
        """Delete a signed contract"""
        try:
            conn = sqlite3.connect('legal_docs.db')
            c = conn.cursor()
            
            # Get file path
            c.execute('SELECT file_path FROM signed_contracts WHERE filename = ? AND username = ?', (filename, username))
            result = c.fetchone()
            
            if result:
                file_path = result[0]
                
                # Delete from database
                c.execute('DELETE FROM signed_contracts WHERE filename = ? AND username = ?', (filename, username))
                conn.commit()
                conn.close()
                
                # Delete file from filesystem
                if os.path.exists(file_path):
                    os.remove(file_path)
                
                return True, f"Contract '{filename}' deleted successfully."
            else:
                conn.close()
                return False, "Contract not found."
                
        except Exception as e:
            return False, f"Error deleting contract: {str(e)}"

    def format_file_size(self, size_bytes):
        """Format file size in human-readable format"""
        if size_bytes == 0 or size_bytes is None:
            return "0 B"
        size_names = ["B", "KB", "MB", "GB"]
        i = 0
        while size_bytes >= 1024 and i < len(size_names) - 1:
            size_bytes /= 1024.0
            i += 1
        return f"{size_bytes:.1f} {size_names[i]}"

    def render_login_page(self):
        """Render the login/registration page"""
        st.markdown('<div class="main-header">🎬 Film Production Legal Compliance Assistant</div>', unsafe_allow_html=True)
        
        col1, col2, col3 = st.columns([1, 3, 1])
        with col2:
            st.markdown('<div class="login-container">', unsafe_allow_html=True)
            
            tab1, tab2 = st.tabs(["🔐 **LOGIN**", "📝 **REGISTER**"])
            
            with tab1:
                st.subheader("Login to Your Account")
                login_username = st.text_input("👤 Username", key="login_user")
                login_password = st.text_input("🔒 Password", type="password", key="login_pass")
                
                if st.button("🚀 Login", key="login_btn", use_container_width=True):
                    if login_username and login_password:
                        with st.spinner("Authenticating..."):
                            success, result = self.auth_system.login_user(login_username, login_password)
                            if success:
                                st.session_state.logged_in = True
                                st.session_state.username = login_username
                                st.session_state.user_data = result
                                st.success("✅ Login successful!")
                                st.rerun()
                            else:
                                st.error(f"❌ {result}")
                    else:
                        st.warning("⚠️ Please enter both username and password")
        
            with tab2:
                st.subheader("Create New Account")
                col1, col2 = st.columns(2)
                
                with col1:
                    reg_username = st.text_input("👤 Choose Username", key="reg_user")
                    reg_email = st.text_input("📧 Email Address", key="reg_email")
                    reg_phone = st.text_input("📞 Phone Number", key="reg_phone")
                
                with col2:
                    reg_company = st.text_input("🏢 Company Name", key="reg_company")
                    reg_password = st.text_input("🔒 Choose Password", type="password", key="reg_pass")
                    reg_confirm = st.text_input("🔒 Confirm Password", type="password", key="reg_confirm")
                
                if st.button("🚀 Create Account", key="reg_btn", use_container_width=True):
                    if all([reg_username, reg_password, reg_email, reg_phone, reg_company, reg_confirm]):
                        with st.spinner("Creating account..."):
                            success, message = self.auth_system.register_user(
                                reg_username, reg_password, reg_confirm, reg_email, reg_phone, reg_company
                            )
                            if success:
                                st.success(f"✅ {message}")
                                st.rerun()
                            else:
                                st.error(f"❌ {message}")
                    else:
                        st.warning("⚠️ Please fill in all fields")
            
            st.markdown('</div>', unsafe_allow_html=True)

    def render_sidebar_navigation(self):
        """Render the sidebar navigation menu"""
        st.sidebar.title(f"🎬 Welcome, {st.session_state.username}!")
        if st.session_state.user_data:
            st.sidebar.markdown(f"**Company:** {st.session_state.user_data[5]}")
            st.sidebar.markdown(f"**Role:** {st.session_state.user_data[7]}")
        st.sidebar.markdown("---")
        
        menu_options = [
            "📊 Dashboard", 
            "📄 Upload & Analyze Contracts", 
            "📋 Contract Templates", 
            "💬 AI Legal Assistant",
            "👤 Account Settings"
        ]
        
        if self.is_admin_user():
            menu_options.append("👑 Admin Panel")
        
        menu = st.sidebar.radio("📋 **NAVIGATION**", menu_options)
        
        st.sidebar.markdown("---")
        if st.sidebar.button("🚪 Logout", use_container_width=True):
            for key in list(st.session_state.keys()):
                del st.session_state[key]
            st.rerun()
        
        return menu

    def render_dashboard(self):
        """Render main dashboard"""
        try:
            from dashboard import Dashboard
            dashboard = Dashboard(st.session_state.username)
            dashboard.render_dashboard()
        except ImportError:
            st.title("📊 Dashboard")
            st.info("Welcome to your Film Production Legal Compliance Dashboard")

    def render_contract_upload(self):
        """Render contract upload and analysis"""
        st.title("📄 Upload & Analyze Contracts")
        st.info("Upload your film production contracts for analysis.")
        
        uploaded_file = st.file_uploader("Choose a contract file", type=['pdf', 'docx', 'txt'])
        
        if uploaded_file is not None:
            st.success(f"✅ File uploaded: {uploaded_file.name}")
            analysis = self.document_processor.analyze_contract("demo")
            st.subheader("📋 Contract Summary")
            st.info(analysis['summary'])

    def render_templates(self):
        """Render contract templates section"""
        st.title("📋 Contract Templates")
        st.info("Generate custom contract templates.")
        
        contract_prompt = st.text_area("Describe the contract you need:", height=100)
        
        if st.button("🔄 Generate Template"):
            if contract_prompt.strip():
                template = self.generate_custom_template(contract_prompt)
                st.text_area("Generated Template:", value=template, height=300)

    def generate_custom_template(self, prompt):
        """Generate a custom contract template"""
        return f"CUSTOM CONTRACT TEMPLATE\n\nGenerated for: {prompt}\n\n[Contract content here...]"

    def render_ai_assistant(self):
        """Render AI assistant section with enhanced document upload"""
        st.title("💬 AI Legal Assistant")
        
        # Initialize upload state
        if 'upload_success' not in st.session_state:
            st.session_state.upload_success = False
        
        # Document Upload Section
        st.subheader("📎 Upload Signed Contracts")
        
        # File uploader
        uploaded_file = st.file_uploader(
            "Choose a signed contract to upload:",
            type=['pdf', 'docx', 'txt'],
            help="Upload your signed contracts for secure storage. Supported formats: PDF, DOCX, TXT",
            key="signed_contract_upload"
        )
        
        if uploaded_file is not None:
            # Validate file type
            file_type = uploaded_file.type
            file_name = uploaded_file.name
            file_content = uploaded_file.getvalue()
            
            # Display file info
            col1, col2 = st.columns([3, 1])
            with col1:
                st.info(f"📄 Selected file: **{file_name}** ({self.format_file_size(len(file_content))})")
            
            # Check file size (limit to 10MB)
            max_size = 10 * 1024 * 1024  # 10MB
            if len(file_content) > max_size:
                st.error(f"❌ File size exceeds 10MB limit. Please upload a smaller file.")
            else:
                # Upload button
                with col2:
                    if st.button("📤 Upload", key="upload_confirm", use_container_width=True):
                        with st.spinner("Uploading contract..."):
                            success, message = self.save_signed_contract(
                                file_name, 
                                st.session_state.username, 
                                file_content, 
                                file_type
                            )
                            if success:
                                st.success(message)
                                st.session_state.upload_success = True
                                # Clear the file uploader by rerunning
                                st.rerun()
                            else:
                                st.error(message)
        
        # Contract History Section
        st.markdown("---")
        st.subheader("📋 Upload History")
        
        # Get user's signed contracts
        signed_contracts = self.get_user_signed_contracts(st.session_state.username)
        
        if signed_contracts:
            st.info(f"📊 You have {len(signed_contracts)} signed contract(s) stored.")
            
            # Display contracts in a clean table
            for i, contract in enumerate(signed_contracts):
                filename = contract[0]
                upload_date = contract[1]
                file_size = contract[2] if contract[2] is not None else 0
                file_type = contract[3] if len(contract) > 3 else "Unknown"
                
                with st.container():
                    col1, col2, col3, col4, col5 = st.columns([3, 2, 2, 2, 1])
                    
                    with col1:
                        # File icon based on type
                        file_icon = "📄"
                        if file_type and 'pdf' in file_type.lower():
                            file_icon = "📕"
                        elif file_type and 'word' in file_type.lower() or filename.endswith('.docx'):
                            file_icon = "📘"
                        elif filename.endswith('.txt'):
                            file_icon = "📝"
                        
                        st.write(f"{file_icon} **{filename}**")
                    
                    with col2:
                        st.write(f"**Uploaded:**")
                        st.write(f"{upload_date[:16]}")
                    
                    with col3:
                        st.write(f"**Size:**")
                        st.write(f"{self.format_file_size(file_size)}")
                    
                    with col4:
                        st.write(f"**Type:**")
                        type_display = "PDF" if 'pdf' in file_type.lower() else "Word" if 'word' in file_type.lower() else "Text" if 'text' in file_type.lower() else "Unknown"
                        st.write(f"{type_display}")
                    
                    with col5:
                        # Download button
                        file_path = f"data/signed_contracts/{filename}"
                        if os.path.exists(file_path):
                            with open(file_path, "rb") as f:
                                file_data = f.read()
                                st.download_button(
                                    label="📥",
                                    data=file_data,
                                    file_name=filename,
                                    mime="application/octet-stream",
                                    key=f"dl_{filename}_{i}",
                                    help="Download contract"
                                )
                        else:
                            st.write("❌")
                    
                    st.markdown("---")
        
        else:
            st.info("📭 No signed contracts uploaded yet. Upload your first contract above!")
        
        # AI Chat Section
        st.markdown("---")
        st.subheader("💬 Chat with AI Assistant")
        
        # Initialize chat history
        if "messages" not in st.session_state:
            st.session_state.messages = [
                {"role": "assistant", "content": "Hello! I'm your AI Legal Assistant. I can help you with contract analysis, compliance questions, and film production legal matters."}
            ]
        
        # Display chat messages
        for message in st.session_state.messages:
            with st.chat_message(message["role"]):
                st.markdown(message["content"])
        
        # Chat input
        if prompt := st.chat_input("Ask a legal question about film production..."):
            # Add user message to chat history
            st.session_state.messages.append({"role": "user", "content": prompt})
            with st.chat_message("user"):
                st.markdown(prompt)
            
            # Generate AI response
            with st.chat_message("assistant"):
                with st.spinner("Analyzing your question..."):
                    response = self.chat_handler.get_response(prompt, [])
                    st.markdown(response)
            
            st.session_state.messages.append({"role": "assistant", "content": response})

    def render_account_settings(self):
        """Render account settings"""
        st.title("👤 Account Settings")
        if st.session_state.user_data:
            st.write(f"**Username:** {st.session_state.username}")
            st.write(f"**Email:** {st.session_state.user_data[3]}")
            st.write(f"**Company:** {st.session_state.user_data[5]}")
            st.write(f"**Role:** {st.session_state.user_data[7]}")
            st.write(f"**Member since:** {st.session_state.user_data[6][:10] if st.session_state.user_data[6] else 'N/A'}")

    def run(self):
        """Main application runner"""
        st.set_page_config(
            page_title="Film Production Legal Compliance Assistant",
            page_icon="🎬",
            layout="wide"
        )

        st.markdown("""
        <style>
            .main-header {
                font-size: 2.5rem;
                font-weight: bold;
                text-align: center;
                color: #1f77b4;
                margin-bottom: 2rem;
                padding: 1rem;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                border-radius: 10px;
                color: white;
            }
            .login-container {
                background-color: #f8f9fa;
                padding: 2rem;
                border-radius: 10px;
                border: 1px solid #dee2e6;
            }
        </style>
        """, unsafe_allow_html=True)

        # Initialize session state
        if 'logged_in' not in st.session_state:
            st.session_state.logged_in = False
        if 'username' not in st.session_state:
            st.session_state.username = None
        if 'user_data' not in st.session_state:
            st.session_state.user_data = None

        # Main app logic
        if not st.session_state.logged_in:
            self.render_login_page()
        else:
            menu = self.render_sidebar_navigation()
            
            if menu == "📊 Dashboard":
                self.render_dashboard()
            elif menu == "📄 Upload & Analyze Contracts":
                self.render_contract_upload()
            elif menu == "📋 Contract Templates":
                self.render_templates()
            elif menu == "💬 AI Legal Assistant":
                self.render_ai_assistant()
            elif menu == "👤 Account Settings":
                self.render_account_settings()
            elif menu == "👑 Admin Panel":
                from admin import AdminPanel
                admin_panel = AdminPanel()
                admin_panel.render_admin_panel()

# Run the application
if __name__ == "__main__":
    app = LegalComplianceApp()
    app.run()