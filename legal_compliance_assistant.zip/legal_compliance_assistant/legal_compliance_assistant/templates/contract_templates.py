class ContractTemplates:
    def __init__(self):
        self.templates = self.load_templates()
    
    def load_templates(self):
        """Load contract templates"""
        return {
            "Actor Agreement": self.get_actor_agreement_template(),
            "Location Release": self.get_location_release_template(),
            "Crew Agreement": self.get_crew_agreement_template(),
            "Music License": self.get_music_license_template(),
            "Distribution Agreement": self.get_distribution_agreement_template()
        }
    
    def get_template(self, template_type):
        """Get specific template"""
        return self.templates.get(template_type, "Template not available.")
    
    def get_actor_agreement_template(self):
        return """ACTOR AGREEMENT

This Actor Agreement ("Agreement") is made as of [Date] between:

PRODUCTION COMPANY: [Company Name], with offices at [Address] ("Producer")

AND

ACTOR: [Actor Name], residing at [Address] ("Actor")

1. ENGAGEMENT: Producer engages Actor to render services in the motion picture tentatively titled "[Film Title]" ("Picture").

2. SERVICES: Actor agrees to render all acting services required by Producer.

3. COMPENSATION:
   - Base Compensation: $[Amount] payable as follows: [Payment schedule]

4. CREDIT: Actor shall receive [Type of credit] credit.

5. RIGHTS: Producer shall own all rights to Actor's performance.

IN WITNESS WHEREOF, the parties have executed this Agreement.

PRODUCER: ____________________________
ACTOR: ____________________________
DATE: ____________________________
"""
    
    def get_location_release_template(self):
        return """LOCATION RELEASE AGREEMENT

This Location Release Agreement is made between:

PRODUCTION COMPANY: [Company Name] ("Producer")
LOCATION OWNER: [Owner Name] ("Owner")

1. LOCATION: [Full address and description]

2. GRANT OF RIGHTS: Owner grants Producer the right to use the Location.

3. TERM: From [Start Date] to [End Date].

4. COMPENSATION: $[Amount] as full payment.

5. INSURANCE: Producer agrees to maintain liability insurance.

IN WITNESS WHEREOF...
"""
    
    def get_crew_agreement_template(self):
        return """CREW AGREEMENT

[Similar structure as actor agreement but tailored for crew positions]
"""
    
    def get_music_license_template(self):
        return """MUSIC LICENSE AGREEMENT

[Template for licensing music for film production]
"""
    
    def get_distribution_agreement_template(self):
        return """DISTRIBUTION AGREEMENT

[Template for film distribution rights and terms]
"""