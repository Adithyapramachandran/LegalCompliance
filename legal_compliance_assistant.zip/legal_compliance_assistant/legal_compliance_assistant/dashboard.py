import streamlit as st
import sqlite3
from datetime import datetime

class Dashboard:
    def __init__(self, username):
        self.username = username
        self.init_dashboard_db()
    
    def init_dashboard_db(self):
        """Initialize dashboard database with contracts table"""
        conn = sqlite3.connect('legal_docs.db')
        c = conn.cursor()
        
        c.execute('''
            CREATE TABLE IF NOT EXISTS dashboard_contracts (
                contract_id TEXT PRIMARY KEY,
                contract_name TEXT NOT NULL,
                status TEXT NOT NULL,
                reviewed_by TEXT,
                created_at TEXT,
                last_updated TEXT,
                username TEXT
            )
        ''')
        
        # Insert sample data if empty
        c.execute('SELECT COUNT(*) FROM dashboard_contracts WHERE username = ?', (self.username,))
        count = c.fetchone()[0]
        
        if count == 0:
            sample_contracts = [
                ('CTR-001', 'Actor Agreement - John Doe', 'Reviewed', 'Legal Team A', '2024-01-15 10:30:00', datetime.now().strftime('%Y-%m-%d %H:%M:%S'), self.username),
                ('CTR-002', 'Location Release - Studio XYZ', 'Pending Review', None, '2024-01-16 09:15:00', datetime.now().strftime('%Y-%m-%d %H:%M:%S'), self.username),
                ('CTR-003', 'Crew Agreement - Production Team', 'Under Review', 'Legal Team B', '2024-01-14 16:45:00', datetime.now().strftime('%Y-%m-%d %H:%M:%S'), self.username),
                ('CTR-004', 'Music Licensing Contract', 'Approved', 'Legal Team A', '2024-01-12 13:20:00', datetime.now().strftime('%Y-%m-%d %H:%M:%S'), self.username),
            ]
            
            c.executemany('''
                INSERT OR IGNORE INTO dashboard_contracts 
                (contract_id, contract_name, status, reviewed_by, created_at, last_updated, username)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', sample_contracts)
        
        conn.commit()
        conn.close()
    
    def get_user_contracts(self):
        """Get all contracts for the current user"""
        try:
            conn = sqlite3.connect('legal_docs.db')
            c = conn.cursor()
            c.execute('''
                SELECT contract_id, contract_name, status, reviewed_by, created_at, last_updated
                FROM dashboard_contracts 
                WHERE username = ? 
                ORDER BY created_at DESC
            ''', (self.username,))
            contracts = c.fetchall()
            conn.close()
            return contracts
        except Exception as e:
            st.error(f"Error retrieving contracts: {e}")
            return []

    def get_user_role(self):
        """Get the current user's role"""
        try:
            conn = sqlite3.connect('users.db')
            c = conn.cursor()
            c.execute('SELECT role FROM users WHERE username = ?', (self.username,))
            result = c.fetchone()
            conn.close()
            return result[0] if result else 'user'
        except:
            return 'user'

    def render_dashboard(self):
        """Render the main dashboard"""
        
        user_role = self.get_user_role()
        
        # Welcome message with role
        st.markdown(f"""
        <div style='text-align: center; padding: 2rem 1rem; margin-bottom: 2rem;'>
            <h1 style='font-size: 2.8rem; font-weight: 700; color: #1f77b4; margin-bottom: 0.5rem;'>
                Welcome back, {self.username}!
            </h1>
            <p style='font-size: 1.2rem; color: #555; font-weight: 400;'>
                Role: <strong>{user_role.upper()}</strong> • Legal Compliance Assistant
            </p>
        </div>
        """, unsafe_allow_html=True)
        
        # Quick stats
        contracts = self.get_user_contracts()
        
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            total_contracts = len(contracts)
            st.metric("Total Contracts", total_contracts)
        
        with col2:
            pending = len([c for c in contracts if c[2] == 'Pending Review'])
            st.metric("Pending Review", pending)
        
        with col3:
            reviewed = len([c for c in contracts if c[2] in ['Reviewed', 'Approved']])
            st.metric("Reviewed/Approved", reviewed)
        
        with col4:
            in_progress = len([c for c in contracts if c[2] == 'Under Review'])
            st.metric("In Progress", in_progress)
        
        st.markdown("---")
        
        # Contracts Table
        st.subheader("📋 My Contracts")
        
        if contracts:
            # Create table data
            table_data = []
            
            for contract in contracts:
                contract_id, contract_name, status, reviewed_by, created_at, last_updated = contract
                
                # Status color coding
                status_color = {
                    'Pending Review': '🟡',
                    'Under Review': '🔵', 
                    'Reviewed': '🟢',
                    'Approved': '✅',
                    'Rejected': '🔴'
                }.get(status, '⚪')
                
                table_data.append({
                    "Contract ID": contract_id,
                    "Contract Name": contract_name,
                    "Status": f"{status_color} {status}",
                    "Reviewed By": reviewed_by or "Not assigned",
                    "Created": created_at[:16] if created_at else "N/A",
                    "Last Updated": last_updated[:16] if last_updated else "N/A"
                })
            
            # Display the table
            st.dataframe(
                table_data,
                use_container_width=True,
                column_config={
                    "Contract ID": st.column_config.TextColumn(width="small"),
                    "Contract Name": st.column_config.TextColumn(width="large"),
                    "Status": st.column_config.TextColumn(width="medium"),
                    "Reviewed By": st.column_config.TextColumn(width="medium"),
                    "Created": st.column_config.TextColumn(width="medium"),
                    "Last Updated": st.column_config.TextColumn(width="medium")
                },
                hide_index=True
            )
            
            st.caption(f"Showing {len(contracts)} contract(s)")
            
        else:
            st.info("No contracts found. Start by uploading your first contract!")
        
        # Role-specific features
        st.markdown("---")
        
        if user_role == 'legal':
            st.subheader("⚖️ Legal Team Features")
            st.info("As a legal team member, you have access to contract review and compliance monitoring tools.")
            
            col1, col2 = st.columns(2)
            with col1:
                if st.button("📋 Review Pending Contracts", use_container_width=True):
                    st.success("Redirecting to contract review...")
            
            with col2:
                if st.button("📊 Compliance Report", use_container_width=True):
                    st.success("Generating compliance report...")
        
        elif user_role == 'production':
            st.subheader("🎬 Production Team Features")
            st.info("As a production team member, you have access to template generation and quick contract tools.")
            
            col1, col2 = st.columns(2)
            with col1:
                if st.button("📄 Generate Contract Template", use_container_width=True):
                    st.success("Opening template generator...")
            
            with col2:
                if st.button("🚀 Quick Contract Setup", use_container_width=True):
                    st.success("Starting quick contract setup...")